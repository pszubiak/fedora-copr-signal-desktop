// Copyright 2020-2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import React from 'react';

import { LocalizerType } from '../types/Util';

type PropsType = {
  hasExpired: boolean;
  i18n: LocalizerType;
};

export const ExpiredBuildDialog = ({
  hasExpired,
  i18n,
}: PropsType): JSX.Element | null => {
  if (!hasExpired) {
    return null;
  }

  return (
    <div className="module-left-pane-dialog module-left-pane-dialog--error">
      {i18n('expiredWarning')}
      <div className="module-left-pane-dialog__actions">
        <a
          className="module-left-pane-dialog__link"
          href="https://signal.org/download/"
          rel="noreferrer"
          tabIndex={-1}
          target="_blank"
        >
          <button type="button" className="upgrade">
            {i18n('upgrade')}
          </button>
        </a>
      </div>
    </div>
  );
};
