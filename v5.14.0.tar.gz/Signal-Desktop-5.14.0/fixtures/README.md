<!-- Copyright 2018-2020 Signal Messenger, LLC -->
<!-- SPDX-License-Identifier: AGPL-3.0-only -->

A collection of files for generating attachments for load testing. These files
were made available in the public domain.

Add more files to this directory for `Signal.Debug` to pick up.
