// Copyright 2015-2020 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

/* global libphonenumber, Whisper, $ */

// eslint-disable-next-line func-names
(function () {
  window.Whisper = window.Whisper || {};

  Whisper.PhoneInputView = Whisper.View.extend({
    tagName: 'div',
    className: 'phone-input',
    template: () => $('#phone-number').html(),
    initialize() {
      this.$('input.number').intlTelInput();
    },
    events: {
      change: 'validateNumber',
      keydown: 'validateNumber',
    },
    validateNumber() {
      const input = this.$('input.number');
      const regionCode = this.$('li.active')
        .attr('data-country-code')
        .toUpperCase();
      const number = input.val();

      const parsedNumber = libphonenumber.util.parseNumber(number, regionCode);
      if (parsedNumber.isValidNumber) {
        this.$('.number-container').removeClass('invalid');
        this.$('.number-container').addClass('valid');
      } else {
        this.$('.number-container').removeClass('valid');
      }
      input.trigger('validation');

      return parsedNumber.e164;
    },
  });
})();
